DROP TABLE IF EXISTS wardens;
DROP TABLE IF EXISTS students;
DROP TABLE IF EXISTS users;

CREATE TABLE users (
  id VARCHAR(50) NOT NULL,
  role ENUM('student','warden') NOT NULL,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(100) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  PRIMARY KEY (id)
);

CREATE TABLE students (
  stu_id VARCHAR(50) NOT NULL,
  college VARCHAR(200) NOT NULL,
  name VARCHAR(200) NOT NULL,
  email VARCHAR(200) NOT NULL UNIQUE,
  dob DATE,
  phone_contact BIGINT,
  room_no INT,
  parent_name VARCHAR(50),
  parent_contact BIGINT,
  department VARCHAR(50),
  admission_at DATE,
  idproofurl VARCHAR(100),
  pfpurl VARCHAR(100),
  CHECK (parent_contact BETWEEN 1000000000 AND 9999999999),
  PRIMARY KEY (stu_id),
  FOREIGN KEY (stu_id) REFERENCES users(id)
    ON DELETE CASCADE
    ON UPDATE CASCADE
);

CREATE TABLE wardens (
  war_id VARCHAR(50) NOT NULL,
  name VARCHAR(200) NOT NULL,
  email VARCHAR(200) NOT NULL UNIQUE,
  dob DATE,
  phone_contact BIGINT,
  idproofurl VARCHAR(100),
  pfpurl VARCHAR(100),
  CHECK (phone_contact BETWEEN 1000000000 AND 9999999999),
  PRIMARY KEY (war_id),
  FOREIGN KEY (war_id) REFERENCES users(id)
    ON DELETE CASCADE
    ON UPDATE CASCADE
);

DROP TABLE IF EXISTS complaints;
CREATE TABLE complaints (
  id INT AUTO_INCREMENT PRIMARY KEY,
  student_id VARCHAR(50) NOT NULL,
  title VARCHAR(100) NOT NULL,
  description VARCHAR(500) NOT NULL,
  priority ENUM('Low','Medium','High') DEFAULT 'Medium',
  status ENUM('Submitted','Pending','Resolved','Rejected') DEFAULT 'Submitted',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

DROP TABLE IF EXISTS escort_requests;
CREATE TABLE escort_requests (
  id INT AUTO_INCREMENT PRIMARY KEY,
  student_id VARCHAR(50) NOT NULL,
  student_name VARCHAR(100),
  reason TEXT NOT NULL,
  location VARCHAR(100) NOT NULL,
  time DATETIME NOT NULL,
  status ENUM('Pending','Assigned','Completed') DEFAULT 'Pending',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

DROP TABLE IF EXISTS night_out_requests;
CREATE TABLE night_out_requests (
  id INT AUTO_INCREMENT PRIMARY KEY,
  student_id VARCHAR(50) NOT NULL,
  student_name VARCHAR(100),
  from_date DATETIME NOT NULL,
  to_date DATETIME NOT NULL,
  reason TEXT NOT NULL,
  parent_contact BIGINT,
  status ENUM('Pending','Approved','Rejected') DEFAULT 'Pending',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);


DROP TABLE IF EXISTS anonymous_reports;
CREATE TABLE anonymous_reports (
  id INT AUTO_INCREMENT PRIMARY KEY,
  report_type VARCHAR(100) NOT NULL,
  description TEXT NOT NULL,
  img LONGTEXT,
  status ENUM('Submitted','In Review','Closed') DEFAULT 'Submitted',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);


DROP TABLE IF EXISTS announcements;
CREATE TABLE announcements (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(255) NOT NULL,
  content TEXT NOT NULL,
  posted_by VARCHAR(100) NOT NULL,
  status ENUM('Draft','Published','Archived') DEFAULT 'Published',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
